# Steam 창작마당 게시 도구

웹 제작 도구에서 저장한 ZIP을 번역자 본인의 Steam 계정으로 게시하는 Windows 도구다. 개발자 계정·웹 API 키를 받거나 저장하지 않는다.

```powershell
dotnet build Tools/TranslationPatchTool.Publisher/TranslationPatchTool.Publisher.csproj
dotnet publish Tools/TranslationPatchTool.Publisher/TranslationPatchTool.Publisher.csproj -c Release -r win-x64 --self-contained true
```

`steam_api64.dll`과 Steamworks.NET은 프로젝트에 포함된 동일 버전을 사용한다. 네이티브 DLL, Steamworks.NET 고지, 배포에 사용한 Microsoft.NETCore.App.Runtime.win-x64의 LICENSE/THIRD-PARTY-NOTICES, Microsoft.WindowsDesktop.App.Runtime.win-x64의 LICENSE를 실행 파일과 함께 배포한다. 전체 폴더를 ZIP으로 묶고 사용자가 모두 풀어 실행한다. 별도 .NET 설치는 필요하지 않다.

1. Steam에 게임을 소유한 계정으로 로그인한다.
2. 게임의 `steam-full` 카탈로그와 웹에서 만든 게시용 ZIP을 선택해 검사한다. `editor-preview`·데모 팩은 본편 창작마당에 게시하지 않는다.
3. 현재 Steam 계정과 게시 파일 목록, 제목·설명·미리보기, 공개 범위를 확인한다. 기본은 비공개다.
4. 새 항목 또는 본인이 소유한 기존 항목 ID로 게시한다. 생성된 ID는 로컬 계정별 기록에 저장하여 다음 수정에 재사용한다.
5. Steam 약관 확인이 필요한 경우 사용자가 항목 페이지에서 직접 처리한다. 도구는 약관을 대신 수락하지 않는다.

ZIP은 별도의 임시 폴더에 제한적으로 해제한다. 외부 경로·중복 경로·추가 원문 파일·손상된 생성물은 거부하며, 게시 직전에 검사한 파일 해시를 다시 확인한다. 새 항목 생성이 시간 초과되면 중복 생성을 막고 사용자가 Workshop에서 ID를 확인하게 한다. 업로드 중 종료는 막고 요청 결과가 나온 뒤 임시 사본을 정리한다.

`--check-steam`은 앱 ID·로그인·게임 소유 여부만 확인하며 항목 생성이나 업로드를 하지 않는다.

현재 실제 업로드/수정/약관/다른 계정 구독은 검증하지 않았다. Steamworks 관리 화면에서 ISteamUGC 파일 전송 활성화와 Workshop 공개 준비가 남아 있어, 컴파일이나 연결 성공을 게시 성공으로 해석하지 않는다. 게임의 공식 카탈로그 동봉 및 구독/기존 언어 목록 통합은 구현되어 있으며 Editor 격리 검증을 수행했다. 외부 서버 게시와 배포 Player 전체 왕복은 별도 출시 검증으로 남는다.
